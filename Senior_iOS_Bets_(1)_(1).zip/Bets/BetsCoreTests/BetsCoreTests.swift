import XCTest
@testable import BetsCore

class BetsCoreTests: XCTestCase {

}
